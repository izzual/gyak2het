# gyak2
a 2. prog3 gyakorlat egyik feladata
